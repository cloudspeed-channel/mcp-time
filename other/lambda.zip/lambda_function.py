# lambda_mcp_time.py
import json
import os
import requests  # package requests in your Lambda deployment package

MCP_BASE = os.environ.get("MCP_BASE", "http://3.142.240.228:8080")

def lambda_handler(event, context):
    """
    This handles Agent input (function details style). It expects a parameter named "timezone".
    Returns a functionResponse containing TEXT body with JSON of the MCP response.
    """
    # extract params
    params = event.get("parameters", [])  # list of {name,type,value}
    p = {param["name"]: param.get("value") for param in params}
    timezone = p.get("timezone") or p.get("tz") or event.get("requestBody", {}).get("content", {}).get("application/json", {}).get("properties", {}).get("timezone")

    if not timezone:
        # Agent will reprompt or we return a reprompt state - but simple response here:
        response_body = {"TEXT": {"body": json.dumps({"error": "missing timezone parameter"})}}
        function_response = {
            "actionGroup": event.get("actionGroup"),
            "function": event.get("function"),
            "functionResponse": {"responseBody": response_body}
        }
        return {"messageVersion": "1.0", "response": function_response}

    # call the MCP server
    try:
        resp = requests.get(f"{MCP_BASE}/time/current", params={"timezone": timezone}, timeout=5)
        resp.raise_for_status()
        mcp_json = resp.json()
    except Exception as e:
        mcp_json = {"error": str(e)}

    # Build functionResponse (function details style; TEXT body)
    response_body = {"TEXT": {"body": json.dumps(mcp_json)}}
    function_response = {
        "actionGroup": event.get("actionGroup"),
        "function": event.get("function"),
        "functionResponse": {"responseBody": response_body}
    }
    return {"messageVersion": "1.0", "response": function_response}
